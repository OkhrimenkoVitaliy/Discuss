--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS