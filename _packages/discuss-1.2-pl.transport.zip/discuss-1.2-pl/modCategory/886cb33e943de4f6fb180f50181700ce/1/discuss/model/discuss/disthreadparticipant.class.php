<?php
/**
 * @package discuss
 * [+phpdoc-subpackage+]
 */
class disThreadParticipant extends xPDOObject {}