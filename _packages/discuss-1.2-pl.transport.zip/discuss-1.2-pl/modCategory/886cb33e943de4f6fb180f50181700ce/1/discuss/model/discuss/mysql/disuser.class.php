<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disuser.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disUser_mysql extends disUser {}