<?php
/**
 * @package discuss
 * [+phpdoc-subpackage+]
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disthreadparticipant.class.php');
/**
 * @package discuss
 * [+phpdoc-subpackage+]
 */
class disThreadParticipant_mysql extends disThreadParticipant {}