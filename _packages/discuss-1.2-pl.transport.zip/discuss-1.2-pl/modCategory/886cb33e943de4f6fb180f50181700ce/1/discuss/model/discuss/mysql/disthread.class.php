<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disthread.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disThread_mysql extends disThread {}