<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/dispostclosure.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disPostClosure_mysql extends disPostClosure {}