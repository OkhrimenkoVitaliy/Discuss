<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'disBoard',
    1 => 'disBoardUserGroup',
    2 => 'disCategory',
    3 => 'disModerator',
    4 => 'disThread',
    5 => 'disThreadRead',
    6 => 'disPost',
    7 => 'disPostAttachment',
    8 => 'disUserFriend',
    9 => 'disUserGroupProfile',
    10 => 'disUser',
    11 => 'disUserModerated',
    12 => 'disUserNotification',
    13 => 'disForumActivity',
    14 => 'disLogActivity',
  ),
  'xPDOObject' => 
  array (
    0 => 'disBoardClosure',
    1 => 'disThreadUser',
    2 => 'disThreadParticipant',
    3 => 'disPostClosure',
    4 => 'disReservedUsername',
    5 => 'disSession',
  ),
  'disThread' => 
  array (
    0 => 'disThreadDiscussion',
    1 => 'disThreadQuestion',
  ),
);