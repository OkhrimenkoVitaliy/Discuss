<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/discategory.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disCategory_mysql extends disCategory {}