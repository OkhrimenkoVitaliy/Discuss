<?php
/**
 * Default English Lexicon Entries for Discuss
 *
 * @package discuss
 * @subpackage lexicon
 */
$_lang['discuss'] = 'Дискусии';
$_lang['discuss.menu_desc'] = 'Динамичен дискусионен модул';